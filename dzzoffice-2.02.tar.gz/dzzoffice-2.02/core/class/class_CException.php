<?php
if(!defined('IN_DZZ')) {
	exit('Access Denied');
}

class CException extends Exception{

}
?>